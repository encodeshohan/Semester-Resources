%*Generate a composite signal using two simple signals as, 
 %x = A1 sin(2?((C+D+H)*100)t ) + A2 cos(2?((D+E+H)*100)t) + s*randn(size(t)); 
 %A1 = (A+B+H), A2 = (B+C+H) and s =  (C+D+H)/30 
 
 %22-46947-1
 %AB-CDEFG-H
 
 A1= 5;
 A2 = 9;
 S = (11/30);
 
 
 
 