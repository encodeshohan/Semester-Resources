<?php
    $length = 30;
    $width = 15;

    $area = $length * $width;
    $perimeter = 2 * ($length + $width);

    echo("Length : " . $length . "<br>");
    echo("Width : " . $width . "<br>");

    echo("<br>");

    echo("The area of a Rectangle : " . $area. "<br>");
    echo("Perimeter : ".$perimeter. "<br>")
?>