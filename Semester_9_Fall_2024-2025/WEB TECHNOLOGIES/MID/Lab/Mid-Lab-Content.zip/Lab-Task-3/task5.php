<?php
    echo("Odd Numbers between 10 to 100 is : ". "<br>");

    for ($i = 10; $i <= 100; $i++) 
    {
        if ($i %2 != 0)
        {
            echo($i ."<br>");
        }
    }
?>