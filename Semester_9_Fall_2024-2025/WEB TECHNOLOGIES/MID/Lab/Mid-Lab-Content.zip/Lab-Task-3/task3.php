<?php
    $n = 4;
    echo("Number: ". $n."<br>");

    echo("<br>");

    if ($n%2 == 0) 
    {
        echo("Number ". $n . " is EVEN." . "<br>");
    }
    else
    {
        echo("Number ". $n . " is ODD." . "<br>");
    }
?>