#!/bin/bash
#Write a shell script to calculate the word count of a file named notes.txt using system variables. 

echo "Hello World" > notes.txt
wc -w < notes.txt
