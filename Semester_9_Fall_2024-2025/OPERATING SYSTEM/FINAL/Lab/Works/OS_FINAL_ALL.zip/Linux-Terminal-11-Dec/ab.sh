#!/bin/bash
echo "Good Morning"
date
read name
echo "Hello $name"
# Add Two number
read n1
read n2
echo "Addition of $n1 & $n2 is : $(($n1+$n2))"
