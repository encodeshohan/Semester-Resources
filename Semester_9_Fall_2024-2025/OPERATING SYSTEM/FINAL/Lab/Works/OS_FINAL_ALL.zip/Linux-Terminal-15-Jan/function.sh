#!/bin/bash
myFunction()
{
	echo "Oh! Actually, it Works"
}
myFunction
